/* Commento di prova */

package main

// commento alla funzione
func main() {
	i := 03
	a := 0
        int *puntatore
	float32 floatNumber 10.2 
	10i
	
        String stringa := "waw"
	for i < 100 {
		a += i
	}

	if a < 100 {
		a = 0xFF
	} else {
		a *= 20
	}
}
