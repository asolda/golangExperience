package lexer;

import java.util.Hashtable;

public class Tables {
	
	public static Hashtable symTable = new Hashtable();
	public static Hashtable stringTable = new Hashtable();
	public static Hashtable numTable = new Hashtable();
	

}
