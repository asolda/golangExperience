//pakage main
/* commento su 
piu linee */

func mmain6() {
    var zz inte
    
    fori := 0; i < 10; i+++ {
        _nosense(i)
    }

    String stringa = "Stringa senza chiusura"
   
     

    '
}
