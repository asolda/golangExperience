break
default
func
interface
select
case
defer
go
map
struct
chan
else
goto
package
switch
const
if
range
type
continue
for
import
return
var
"una stringa"
123
0xA
wdwqd
int sadsadsadsadasd
||


