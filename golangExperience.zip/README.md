# golangExperience
Some sources in go I'm working on while I'm studying the language

Please note that part of this code was written to solve some assignments as part of the Compiler class at University of Salerno. Assignments can be found in the root directory of the package.
